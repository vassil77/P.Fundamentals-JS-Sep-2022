// RegExp literal
let pattern = /[A-Za-z0-9]+/gi;

// RegExp constructor
let regexp = new RegExp('[A-Za-z0-9]', 'gi');

// RegExp methods
// String methods that uses RegExp